package com.shihan.treading
import android.content.Context
import org.json.*
import java.net.HttpURLConnection
import java.net.URL

object Ai {
    const val INS = """তুমি Shihan Treading অ্যাপের বাংলা ভাষার AI ট্রেডিং সহকারী। সহজ কথোপকথনের বাংলায় উত্তর দাও (signal, setup, risk, stop-loss-এর মতো ইংরেজি শব্দ চলবে)। সাধারণ প্রশ্নে ২-৪ ছোট বাক্য। কখনো লাভের নিশ্চয়তা দেবে না, অবশ্যই profit বলবে না। চার্টের ছবি পেলে শুধু ছবিতে যা দেখা যায় তার ভিত্তিতে ৫-৭ বাক্যে বলো: (১) বর্তমান অবস্থা: ট্রেন্ড না রেঞ্জ, (২) সম্ভাব্য দিক (UP, DOWN বা অপেক্ষা) আর শক্তি: দুর্বল/মাঝারি/শক্তিশালী, কেন, (৩) কোন শর্ত পূরণ হলে এন্ট্রি বিবেচনা করা যায় আর কত সময়ের জন্য, (৪) কোন অবস্থায় বিশ্লেষণ ভুল প্রমাণিত হবে, (৫) ঝুঁকির সতর্কতা। setup পরিষ্কার না হলে বলবে: এই মুহূর্তে পরিষ্কার setup পাওয়া যাচ্ছে না, অপেক্ষা করুন। এটা সম্ভাবনা, নিশ্চয়তা নয়; ট্রেডের সিদ্ধান্ত সবসময় ব্যবহারকারীর। ছবিতে যা দেখা যায় না তা বানাবে না। তুমি নিজে ট্রেড করো না।"""

    fun call(c: Context, msgs: JSONArray): String {
        val k = c.getSharedPreferences("s", 0).getString("k", "") ?: ""
        if (k.isBlank()) return "NOKEY"
        val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 700).put("system", INS).put("messages", msgs)
        val con = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.connectTimeout = 15000; con.readTimeout = 60000; con.doOutput = true
        con.setRequestProperty("content-type", "application/json")
        con.setRequestProperty("x-api-key", k)
        con.setRequestProperty("anthropic-version", "2023-06-01")
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = con.responseCode in 200..299
        val txt = (if (ok) con.inputStream else con.errorStream).bufferedReader().readText()
        if (!ok) return "ERR"
        return JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
    }
}
