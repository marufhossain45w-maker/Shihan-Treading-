package com.shihan.treading
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val RC_PROJ = 1
    private val RC_VOICE = 2

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Speaker.init(this)
        window.statusBarColor = 0xFF0B1624.toInt()
        window.decorView.setBackgroundColor(0xFF0B1624.toInt())
        web = WebView(this)
        web.fitsSystemWindows = true
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        Speaker.onState = { s -> js("window.onSpeak&&onSpeak($s)") }
        web.loadUrl("file:///android_asset/index.html")
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9)
    }

    private fun js(c: String) { runOnUiThread { web.evaluateJavascript(c, null) } }
    private fun toast(s: String) { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

    inner class Bridge {
        @JavascriptInterface fun speak(t: String) { Speaker.say(t) }
        @JavascriptInterface fun saveKey(k: String) {
            getSharedPreferences("s", 0).edit().putString("k", k.trim()).apply()
            runOnUiThread { toast("Key সেভ হয়েছে") }
        }
        @JavascriptInterface fun ask(json: String) {
            Thread {
                try {
                    val r = Ai.call(this@MainActivity, JSONArray(json))
                    if (r == "NOKEY" || r == "ERR") js("onAIErr('$r')") else js("onAI(${JSONObject.quote(r)})")
                } catch (e: Exception) { js("onAIErr('ERR')") }
            }.start()
        }
        @JavascriptInterface fun listen() {
            runOnUiThread {
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                try { startActivityForResult(i, RC_VOICE) } catch (e: Exception) { js("onAIErr('NOSTT')") }
            }
        }
        @JavascriptInterface fun startOverlay() {
            runOnUiThread {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    toast("Display over other apps চালু করুন, তারপর আবার ON চাপুন")
                } else {
                    val m = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    startActivityForResult(m.createScreenCaptureIntent(), RC_PROJ)
                }
            }
        }
        @JavascriptInterface fun stopOverlay() { runOnUiThread { stopService(Intent(this@MainActivity, OverlayService::class.java)) } }
    }

    @Deprecated("x")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == RC_PROJ && res == RESULT_OK && d != null) {
            startForegroundService(Intent(this, OverlayService::class.java).putExtra("code", res).putExtra("data", d))
            moveTaskToBack(true)
        }
        if (rc == RC_VOICE && res == RESULT_OK) {
            val t = d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (t != null) js("onHeard(${JSONObject.quote(t)})")
        }
    }
}
