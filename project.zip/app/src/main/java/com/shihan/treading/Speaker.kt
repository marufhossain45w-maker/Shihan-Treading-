package com.shihan.treading
import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

object Speaker {
    private var tts: TextToSpeech? = null
    var onState: ((Boolean) -> Unit)? = null
    fun init(c: Context) {
        if (tts != null) return
        tts = TextToSpeech(c.applicationContext) { st ->
            if (st == TextToSpeech.SUCCESS) tts?.let { t ->
                if (t.setLanguage(Locale("bn", "BD")) < 0) t.setLanguage(Locale("bn", "IN"))
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { onState?.invoke(true) }
                    override fun onDone(id: String?) { onState?.invoke(false) }
                    @Deprecated("x") override fun onError(id: String?) { onState?.invoke(false) }
                })
            }
        }
    }
    fun say(t: String) { tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u") }
}
