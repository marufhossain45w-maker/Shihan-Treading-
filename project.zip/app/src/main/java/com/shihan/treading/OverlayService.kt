package com.shihan.treading
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.Base64
import android.view.*
import android.widget.ImageView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.math.abs

class OverlayService : Service() {
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var wm: WindowManager? = null
    private var orb: ImageView? = null
    private var busy = false
    @Volatile private var last: Bitmap? = null
    private var lastT = 0L
    private val ht = HandlerThread("cap")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i == null) { stopSelf(); return START_NOT_STICKY }
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("s", "Shihan Treading", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "s").setContentTitle("Shihan Treading").setContentText("পর্যবেক্ষণ চলছে").setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val m = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION") val data = i.getParcelableExtra<Intent>("data")!!
        proj = m.getMediaProjection(i.getIntExtra("code", 0), data)
        proj!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, Handler(Looper.getMainLooper()))
        val dm = resources.displayMetrics
        ht.start()
        reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage()
            if (img != null) {
                val now = System.currentTimeMillis()
                if (now - lastT > 500) { lastT = now; last = toBmp(img) }
                img.close()
            }
        }, Handler(ht.looper))
        vd = proj!!.createVirtualDisplay("cap", dm.widthPixels, dm.heightPixels, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        showOrb()
        Speaker.say("আমি এখন ট্রেডিং স্ক্রিন পর্যবেক্ষণ করছি। বিশ্লেষণের জন্য ছোট গোল আইকনে চাপ দিন।")
        return START_NOT_STICKY
    }

    private fun toBmp(img: Image): Bitmap {
        val pl = img.planes[0]; val w = img.width; val h = img.height
        val full = Bitmap.createBitmap(w + (pl.rowStride - pl.pixelStride * w) / pl.pixelStride, h, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(pl.buffer)
        return Bitmap.createBitmap(full, 0, 0, w, h)
    }

    private fun showOrb() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics
        val s = (64 * dm.density).toInt()
        val v = ImageView(this)
        v.setImageResource(R.drawable.orb); v.scaleType = ImageView.ScaleType.CENTER_CROP
        v.outlineProvider = object : ViewOutlineProvider() { override fun getOutline(view: View, o: Outline) { o.setOval(0, 0, view.width, view.height) } }
        v.clipToOutline = true; v.alpha = 0.92f
        val p = WindowManager.LayoutParams(s, s, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START; p.x = dm.widthPixels - s - 16; p.y = 400
        v.setOnTouchListener(object : View.OnTouchListener {
            var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val mx = (e.rawX - dx).toInt(); val my = (e.rawY - dy).toInt()
                        if (abs(mx) > 10 || abs(my) > 10) moved = true
                        if (moved) { p.x = sx + mx; p.y = sy + my; wm!!.updateViewLayout(view, p) }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) analyze()
                }
                return true
            }
        })
        wm!!.addView(v, p); orb = v
    }

    private fun analyze() {
        if (busy) return
        busy = true
        Speaker.say("আমি স্ক্যান করছি।")
        Thread {
            try {
                val bmp = last
                if (bmp == null) { Speaker.say("আমি ট্রেডিং স্ক্রিন দেখতে পাচ্ছি না।"); return@Thread }
                val sc = Bitmap.createScaledBitmap(bmp, bmp.width / 2, bmp.height / 2, true)
                val o = ByteArrayOutputStream(); sc.compress(Bitmap.CompressFormat.JPEG, 75, o)
                val b64 = Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
                val c = JSONArray()
                    .put(JSONObject().put("type", "image").put("source", JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", b64)))
                    .put(JSONObject().put("type", "text").put("text", "এই ট্রেডিং চার্টের বর্তমান অবস্থা বিশ্লেষণ করো: ট্রেন্ড, সম্ভাব্য signal, এন্ট্রির শর্ত আর ঝুঁকি।"))
                val r = Ai.call(this, JSONArray().put(JSONObject().put("role", "user").put("content", c)))
                Speaker.say(when (r) {
                    "NOKEY" -> "AI key দেওয়া হয়নি। অ্যাপের Settings-এ key দিন।"
                    "ERR" -> "আমি এখন বিশ্লেষণ করতে পারছি না।"
                    else -> r
                })
            } catch (e: Exception) { Speaker.say("আমি এখন বিশ্লেষণ করতে পারছি না।") }
            finally { busy = false }
        }.start()
    }

    override fun onDestroy() {
        orb?.let { try { wm?.removeView(it) } catch (e: Exception) {} }
        vd?.release(); reader?.close(); proj?.stop(); ht.quitSafely()
        super.onDestroy()
    }
}
